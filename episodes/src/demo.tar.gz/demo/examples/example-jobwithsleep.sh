#!/bin/bash

sleep 20s
echo -n "This script is running on "
hostname
sleep 20s
echo -n "\nAfter 20 seconds, This script is still running on "
hostname