#!/bin/bash
echo -n "This script is running on "
hostname