#!/bin/bash
#SBATCH -t 00:01:00
echo -n "This script is running on "
sleep 80s # time in seconds
hostname
